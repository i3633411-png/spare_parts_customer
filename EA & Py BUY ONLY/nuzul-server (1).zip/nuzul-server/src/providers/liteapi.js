// مزوّد LiteAPI (Nuitee): أسعار حقيقية ولحظية.
// التوثيق: https://docs.liteapi.travel/reference/post_hotels-rates
//          https://docs.liteapi.travel/reference/get_data-hotels
// المفتاح يُرسل في ترويسة X-API-Key ويبقى على الخادم فقط.
import { distanceKm } from '../cities.js';
import { TTLCache } from '../cache.js';

const BASE = process.env.LITEAPI_BASE_URL || 'https://api.liteapi.travel/v3.0';
const hotelsCache = new TTLCache(50);
const DAY_MS = 24 * 60 * 60 * 1000;

// كلمات تدل على أن العقار شقة أو جناح مفروش وليس فندقاً تقليدياً
const APT_WORDS = /apart|residence|suite|studio|flat|serviced|شقق|شقة|أجنحة|اجنحة|استوديو|مفروش/i;

async function call(path, { method = 'GET', body, query } = {}) {
  const key = process.env.LITEAPI_KEY;
  const url = new URL(BASE + path);
  if (query) Object.entries(query).forEach(([k, v]) => v != null && url.searchParams.set(k, String(v)));
  const res = await fetch(url, {
    method,
    headers: { 'X-API-Key': key, accept: 'application/json', ...(body ? { 'content-type': 'application/json' } : {}) },
    body: body ? JSON.stringify(body) : undefined,
    signal: AbortSignal.timeout(20000),
  });
  const text = await res.text();
  let json; try { json = JSON.parse(text); } catch { json = null; }
  if (!res.ok) {
    const msg = json?.error?.message || json?.message || text.slice(0, 200);
    const err = new Error(`LiteAPI ${res.status}: ${msg}`);
    err.status = res.status;
    throw err;
  }
  return json;
}

// أول قيمة رقمية من حقل قد يكون رقماً أو كائناً {amount} أو مصفوفة [{amount}]
function amountOf(v) {
  if (v == null) return null;
  if (typeof v === 'number') return v;
  if (Array.isArray(v)) return amountOf(v[0]);
  if (typeof v === 'object') return typeof v.amount === 'number' ? v.amount : null;
  return null;
}

// بيانات الفنادق (الاسم، الصورة، النجوم، الموقع) لكل مدينة، تُحفظ 24 ساعة
async function cityHotels(city) {
  const { value } = await hotelsCache.wrap(`hotels:${city.id}`, DAY_MS, async () => {
    const json = await call('/data/hotels', { query: { countryCode: city.cc, cityName: city.en, limit: 1000, language: 'ar' } });
    const map = new Map();
    for (const h of json?.data || []) map.set(String(h.id), h);
    return map;
  });
  return value;
}

// أنواع الوجبات كما يرسلها المزوّد (boardType). RO = بدون وجبات فلا يُعرض كميزة.
const BOARDS = { BB: 'الإفطار مشمول', HB: 'إفطار وعشاء', FB: 'ثلاث وجبات', AI: 'شامل كلياً' };

// الضرائب والرسوم غير المشمولة في السعر (included:false) تُدفع في الفندق
function feesAtHotel(rate) {
  return (rate?.retailRate?.taxesAndFees || [])
    .filter((t) => t && t.included === false && typeof t.amount === 'number')
    .reduce((s, t) => s + t.amount, 0);
}

function normalize(item, meta, city, nights) {
  const roomTypes = item.roomTypes || [];
  let best = null;
  for (const rt of roomTypes) {
    const rate = rt.rates?.[0];
    const base = amountOf(rt.offerRetailRate) ?? amountOf(rate?.retailRate?.total);
    if (base == null) continue;
    // المقارنة على السعر الكامل: سعر الحجز + ما يُدفع في الفندق
    const fees = feesAtHotel(rate);
    const price = base + fees;
    const market = amountOf(rt.suggestedSellingPrice) ?? amountOf(rate?.retailRate?.suggestedSellingPrice);
    if (!best || price < best.price) best = { price, fees, market, rate };
  }
  if (!best) return null;

  const name = meta?.name || item.name || `فندق ${item.hotelId}`;
  let rating = typeof meta?.rating === 'number' ? meta.rating : null;
  if (rating != null && rating <= 5) rating = rating * 2; // توحيد التقييم على مقياس 10
  const stars = meta?.stars ? Math.round(meta.stars) : null;

  return {
    id: String(item.hotelId),
    name,
    type: APT_WORDS.test(name) ? 'apt' : 'hotel',
    stars: stars && stars >= 1 && stars <= 5 ? stars : null,
    rating: rating != null ? Math.round(rating * 10) / 10 : null,
    reviews: meta?.reviewCount ?? null,
    district: meta?.address || city.name,
    dist: distanceKm(meta?.latitude, meta?.longitude, city.lat, city.lng),
    amen: [], // أرقام المرافق (facilityIds) تحتاج مطابقة، راجع README
    freeCancel: best.rate?.cancellationPolicies?.refundableTag === 'RFN',
    board: BOARDS[best.rate?.boardType] || null,
    image: meta?.main_photo || meta?.thumbnail || null,
    offers: [{
      provider: 'LiteAPI',
      total: Math.round(best.price),                          // السعر الكامل الذي يدفعه الضيف
      payAtHotel: best.fees > 0 ? Math.round(best.fees) : 0,  // منه رسوم تُدفع في الفندق
      marketPrice: best.market && best.market > best.price ? Math.round(best.market) : null,
      url: null,
    }],
    nights,
  };
}

export const liteapiProvider = {
  id: 'liteapi',
  label: 'LiteAPI',
  isConfigured: () => Boolean(process.env.LITEAPI_KEY),

  async search({ city, checkin, checkout, guests, currency }) {
    const nights = Math.round((Date.parse(checkout) - Date.parse(checkin)) / DAY_MS);
    const [ratesJson, hotels] = await Promise.all([
      call('/hotels/rates', {
        method: 'POST',
        body: {
          cityName: city.en,
          countryCode: city.cc,
          checkin, checkout, currency,
          guestNationality: process.env.GUEST_NATIONALITY || 'SA',
          occupancies: [{ adults: guests }],
          limit: 60,
          maxRatesPerHotel: 1,
          timeout: 8,
        },
      }),
      cityHotels(city).catch(() => new Map()),
    ]);

    // بعض الردود تُرفق بيانات الفنادق في مصفوفة hotels
    for (const h of ratesJson?.hotels || []) if (h?.id && !hotels.has(String(h.id))) hotels.set(String(h.id), h);

    return (ratesJson?.data || [])
      .map((item) => normalize(item, hotels.get(String(item.hotelId)), city, nights))
      .filter(Boolean);
  },

  // أقل سعر لليلة واحدة في المدينة (لمخطط أرخص الليالي)
  async cheapestNight({ city, date, type, currency }) {
    const next = new Date(Date.parse(date) + DAY_MS).toISOString().slice(0, 10);
    const list = await this.search({ city, checkin: date, checkout: next, guests: 2, currency });
    const prices = list.filter((x) => !type || type === 'all' || x.type === type).map((x) => Math.min(...x.offers.map((o) => o.total)));
    return prices.length ? Math.min(...prices) : null;
  },
};
