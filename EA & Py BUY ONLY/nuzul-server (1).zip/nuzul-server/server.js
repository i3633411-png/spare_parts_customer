// خادم نُزُل
// - يخدم الواجهة من مجلد nuzul-web
// - GET /api/search   أسعار الإقامة للتواريخ المحددة مرتبة من الأرخص
// - GET /api/calendar أقل سعر لليلة خلال الأيام القادمة
// - GET /api/cities   الوجهات المدعومة
import 'dotenv/config';
import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { CITIES, cityById } from './src/cities.js';
import { TTLCache } from './src/cache.js';
import { activeProviders, demoProvider } from './src/providers/index.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
app.disable('x-powered-by');

const SEARCH_TTL = Number(process.env.SEARCH_CACHE_MINUTES || 10) * 60 * 1000;
const CAL_TTL = Number(process.env.CALENDAR_CACHE_HOURS || 6) * 60 * 60 * 1000;
const RATE_LIMIT = Number(process.env.RATE_LIMIT_PER_MINUTE || 30);
const cache = new TTLCache(1000);
const DAY = 24 * 60 * 60 * 1000;

/* ---------- حد الطلبات لكل زائر ---------- */
const hits = new Map();
function rateLimit(req, res, next) {
  const ip = req.headers['x-forwarded-for']?.split(',')[0].trim() || req.socket.remoteAddress || 'x';
  const now = Date.now();
  const rec = hits.get(ip) || { n: 0, reset: now + 60000 };
  if (now > rec.reset) { rec.n = 0; rec.reset = now + 60000; }
  rec.n++;
  hits.set(ip, rec);
  if (hits.size > 5000) hits.clear();
  if (rec.n > RATE_LIMIT) return res.status(429).json({ error: 'طلبات كثيرة، حاول بعد دقيقة.' });
  next();
}

/* ---------- التحقق من المدخلات ---------- */
const isoRe = /^\d{4}-\d{2}-\d{2}$/;
const todayIso = () => new Date().toISOString().slice(0, 10);
function readSearch(q) {
  const city = cityById(String(q.city || ''));
  if (!city) return { error: 'الوجهة غير مدعومة.' };
  const { checkin, checkout } = q;
  if (!isoRe.test(checkin || '') || !isoRe.test(checkout || '')) return { error: 'صيغة التاريخ يجب أن تكون YYYY-MM-DD.' };
  const nights = Math.round((Date.parse(checkout) - Date.parse(checkin)) / DAY);
  if (checkin < todayIso()) return { error: 'تاريخ الوصول يجب أن يكون اليوم أو بعده.' };
  if (nights < 1) return { error: 'تاريخ المغادرة يجب أن يكون بعد تاريخ الوصول.' };
  if (nights > 30) return { error: 'أقصى مدة للبحث 30 ليلة.' };
  const guests = Math.min(6, Math.max(1, parseInt(q.guests, 10) || 2));
  const currency = /^[A-Z]{3}$/.test(q.currency || '') ? q.currency : 'SAR';
  return { city, checkin, checkout, guests, currency, nights };
}

/* ---------- دمج عروض المزوّدين ---------- */
const keyOf = (name) => String(name).toLowerCase().replace(/[^\p{L}\p{N}]+/gu, '');
function merge(lists) {
  const byKey = new Map();
  for (const list of lists) {
    for (const item of list) {
      const k = keyOf(item.name);
      const prev = byKey.get(k);
      if (!prev) { byKey.set(k, { ...item, offers: [...item.offers] }); continue; }
      prev.offers.push(...item.offers);
      prev.image ||= item.image; prev.rating ??= item.rating; prev.stars ??= item.stars; prev.dist ??= item.dist;
      prev.freeCancel ||= item.freeCancel;
    }
  }
  return [...byKey.values()];
}

function bookingUrl(item, s) {
  const t = process.env.BOOKING_URL_TEMPLATE;
  if (!t) return null;
  return t.replace('{hotelId}', encodeURIComponent(item.id)).replace('{checkin}', s.checkin).replace('{checkout}', s.checkout)
    .replace('{guests}', s.guests).replace('{name}', encodeURIComponent(item.name));
}

function finish(items, s) {
  return items.map((it) => {
    const offers = it.offers.filter((o) => Number.isFinite(o.total) && o.total > 0).sort((a, b) => a.total - b.total);
    if (!offers.length) return null;
    const low = offers[0].total, high = offers.at(-1).total;
    const url = bookingUrl(it, s);
    return { ...it, offers: offers.map((o) => ({ ...o, url: o.url || url })), low, high, save: high - low, perNight: Math.round(low / s.nights) };
  }).filter(Boolean).sort((a, b) => a.low - b.low);
}

async function runSearch(s) {
  const live = activeProviders();
  if (live.length) {
    const settled = await Promise.allSettled(live.map((p) => p.search(s)));
    const ok = settled.filter((r) => r.status === 'fulfilled').map((r) => r.value);
    settled.filter((r) => r.status === 'rejected').forEach((r) => console.warn('[provider]', r.reason?.message));
    const results = finish(merge(ok), s);
    if (results.length) return { source: 'live', providers: live.map((p) => p.label), results };
    const failed = settled.some((r) => r.status === 'rejected');
    const demo = finish(await demoProvider.search(s), s);
    return { source: 'demo', notice: failed ? 'تعذّر الوصول لمزوّد الأسعار، تُعرض بيانات تجريبية.' : 'لا توجد أسعار متاحة لهذه التواريخ لدى المزوّد، تُعرض بيانات تجريبية.', results: demo };
  }
  return { source: 'demo', notice: 'لم يُضبط مفتاح مزوّد بعد، تُعرض بيانات تجريبية.', results: finish(await demoProvider.search(s), s) };
}

/* ---------- المسارات ---------- */
app.get('/api/health', (req, res) => res.json({ ok: true, live: activeProviders().map((p) => p.id) }));

app.get('/api/cities', (req, res) => {
  res.json(CITIES.map(({ id, name, country, vat, center, districts }) => ({ id, name, country, vat, center, districts })));
});

app.get('/api/search', rateLimit, async (req, res) => {
  const s = readSearch(req.query);
  if (s.error) return res.status(400).json({ error: s.error });
  const key = ['search', s.city.id, s.checkin, s.checkout, s.guests, s.currency].join('|');
  try {
    const { value, cached } = await cache.wrap(key, SEARCH_TTL, async () => ({ ...(await runSearch(s)), updatedAt: new Date().toISOString() }));
    res.set('Cache-Control', 'no-store');
    res.json({ city: s.city.id, checkin: s.checkin, checkout: s.checkout, nights: s.nights, guests: s.guests, currency: s.currency, cached, ...value });
  } catch (e) {
    console.error('[search]', e);
    res.status(502).json({ error: 'تعذّر جلب الأسعار الآن، حاول مجدداً.' });
  }
});

app.get('/api/calendar', rateLimit, async (req, res) => {
  const city = cityById(String(req.query.city || ''));
  if (!city) return res.status(400).json({ error: 'الوجهة غير مدعومة.' });
  const days = Math.min(14, Math.max(1, parseInt(req.query.days, 10) || 14));
  const type = ['hotel', 'apt'].includes(req.query.type) ? req.query.type : 'all';
  const currency = /^[A-Z]{3}$/.test(req.query.currency || '') ? req.query.currency : 'SAR';
  const key = ['cal', city.id, days, type, currency, todayIso()].join('|');
  try {
    const { value } = await cache.wrap(key, CAL_TTL, async () => {
      const live = activeProviders();
      const provider = live[0] || demoProvider;
      const dates = Array.from({ length: days }, (_, i) => new Date(Date.now() + (i + 1) * DAY).toISOString().slice(0, 10));
      const out = [];
      // ثلاثة طلبات في وقت واحد كحد أقصى حتى لا نتجاوز حدود المزوّد
      for (let i = 0; i < dates.length; i += 3) {
        const chunk = dates.slice(i, i + 3);
        const prices = await Promise.all(chunk.map((date) => provider.cheapestNight({ city, date, type, currency }).catch(() => null)));
        chunk.forEach((date, j) => out.push({ date, price: prices[j] }));
      }
      return { source: live.length ? 'live' : 'demo', days: out, updatedAt: new Date().toISOString() };
    });
    res.json({ city: city.id, currency, ...value });
  } catch (e) {
    console.error('[calendar]', e);
    res.status(502).json({ error: 'تعذّر جلب مخطط الأسعار.' });
  }
});

app.use(express.static(path.join(__dirname, 'nuzul-web'), { extensions: ['html'] }));

const PORT = Number(process.env.PORT || 3000);
app.listen(PORT, () => {
  const live = activeProviders().map((p) => p.label);
  console.log(`نُزُل يعمل على http://localhost:${PORT}`);
  console.log(live.length ? `المزوّدون المفعّلون: ${live.join('، ')}` : 'لا يوجد مفتاح مزوّد، الموقع يعمل على البيانات التجريبية.');
});
