// اختبار سريع بلا إنترنت: يتحقق من المزوّد التجريبي ومن قراءة ردود LiteAPI بردود وهمية.
// التشغيل: npm test
import assert from 'node:assert/strict';
import { cityById } from '../src/cities.js';
import { demoProvider } from '../src/providers/demo.js';
import { liteapiProvider } from '../src/providers/liteapi.js';

const city = cityById('makkah');
const d = (n) => new Date(Date.now() + n * 864e5).toISOString().slice(0, 10);
const s = { city, checkin: d(3), checkout: d(5), guests: 2, currency: 'SAR' };

// 1) المزوّد التجريبي
const demo = await demoProvider.search(s);
assert.equal(demo.length, 16);
assert.ok(demo.every((x) => x.offers.length === 3 && x.nights === 2));
console.log('✓ demo provider:', demo.length, 'properties');

// 2) LiteAPI بردود وهمية بشكل الوثائق
process.env.LITEAPI_KEY = 'sand_test';
const calls = [];
globalThis.fetch = async (url, opts = {}) => {
  calls.push({ url: String(url), opts });
  const u = new URL(url);
  const body = u.pathname.endsWith('/data/hotels')
    ? { data: [
        { id: 'lp1', name: 'Test Tower Hotel', main_photo: 'https://example.com/a.jpg', stars: 5, rating: 8.7, reviewCount: 1200, latitude: 21.419, longitude: 39.826, address: 'Ajyad' },
        { id: 'lp2', name: 'Haram View Apartments', stars: 3, rating: 4.1, latitude: 21.43, longitude: 39.84 },
      ] }
    : { data: [
        { hotelId: 'lp1', roomTypes: [
          { offerRetailRate: { amount: 1520.4, currency: 'SAR' }, rates: [{ boardName: 'Room Only', retailRate: { total: [{ amount: 1520.4, currency: 'SAR' }] }, cancellationPolicies: { refundableTag: 'RFN' } }] },
          { offerRetailRate: { amount: 1800, currency: 'SAR' }, rates: [{ retailRate: { total: [{ amount: 1800 }] } }] },
        ] },
        { hotelId: 'lp2', roomTypes: [{ rates: [{ boardType: 'BB', boardName: 'Breakfast', retailRate: { total: [{ amount: 640 }] }, cancellationPolicies: { refundableTag: 'NRFN' } }] }] },
        { hotelId: 'lp3', roomTypes: [] },
      ] };
  return new Response(JSON.stringify(body), { status: 200, headers: { 'content-type': 'application/json' } });
};

const live = await liteapiProvider.search(s);
const rates = calls.find((c) => c.url.includes('/hotels/rates'));
assert.equal(rates.opts.headers['X-API-Key'], 'sand_test');
const sent = JSON.parse(rates.opts.body);
assert.equal(sent.cityName, 'Mecca'); assert.equal(sent.countryCode, 'SA'); assert.equal(sent.occupancies[0].adults, 2);
assert.equal(live.length, 2, 'hotel without rooms is dropped');
const [a, b] = live;
assert.equal(a.name, 'Test Tower Hotel'); assert.equal(a.offers[0].total, 1520); assert.equal(a.freeCancel, true); assert.equal(a.type, 'hotel'); assert.ok(a.dist < 1);
assert.equal(b.type, 'apt'); assert.equal(b.rating, 8.2, '5-point rating scaled to 10'); assert.equal(b.freeCancel, false); assert.equal(b.board, 'الإفطار مشمول');
console.log('✓ liteapi adapter parses rates, hotel data, type and distance');


// 3) رد حقيقي من بيئة تجربة LiteAPI (محفوظ في test/fixtures)
import { readFileSync } from 'node:fs';
const real = JSON.parse(readFileSync(new URL('./fixtures/liteapi-rates-sandbox.json', import.meta.url), 'utf8'));
globalThis.fetch = async (url) => {
  const body = new URL(url).pathname.endsWith('/data/hotels') ? { data: [{ id: 'lp1897', name: 'Sandbox Sample Hotel', stars: 4, rating: 8.1 }] } : real;
  return new Response(JSON.stringify(body), { status: 200 });
};
const [r] = await liteapiProvider.search(s);
// الغرفة الأولى 675.23 + رسوم غير مشمولة (10.5 + 99.6 + 120) = 905.33، والثانية 720.9 شاملة كل الضرائب
assert.equal(r.offers[0].total, 721, 'cheapest by full price is the fully-inclusive room');
assert.equal(r.offers[0].payAtHotel, 0);
assert.equal(r.board, null, 'Room Only is not shown as a perk');
assert.equal(r.freeCancel, true);
assert.equal(r.offers[0].marketPrice, 894);
console.log('✓ real sandbox response: fees at hotel counted, cheapest full price =', r.offers[0].total);
console.log('All checks passed.');
