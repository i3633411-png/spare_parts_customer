// ذاكرة مؤقتة بسيطة داخل الخادم مع مدة صلاحية. تُستبدل بـ Redis عند التوسع.
export class TTLCache {
  constructor(maxEntries = 500) {
    this.map = new Map();
    this.max = maxEntries;
    this.inflight = new Map();
  }
  get(key) {
    const hit = this.map.get(key);
    if (!hit) return undefined;
    if (Date.now() > hit.expires) { this.map.delete(key); return undefined; }
    return hit.value;
  }
  set(key, value, ttlMs) {
    if (this.map.size >= this.max) this.map.delete(this.map.keys().next().value);
    this.map.set(key, { value, expires: Date.now() + ttlMs });
  }
  // يمنع إرسال الطلب نفسه للمزوّد مرتين في الوقت نفسه
  async wrap(key, ttlMs, fn) {
    const cached = this.get(key);
    if (cached !== undefined) return { value: cached, cached: true };
    if (this.inflight.has(key)) return { value: await this.inflight.get(key), cached: true };
    const p = (async () => fn())();
    this.inflight.set(key, p);
    try {
      const value = await p;
      this.set(key, value, ttlMs);
      return { value, cached: false };
    } finally {
      this.inflight.delete(key);
    }
  }
}
