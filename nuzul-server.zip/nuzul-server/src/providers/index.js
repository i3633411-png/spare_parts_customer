// سجل المزوّدين. لإضافة مزوّد جديد (مثل Booking.com بعد القبول):
// 1) أنشئ ملفاً في هذا المجلد يصدّر كائناً فيه: id, label, isConfigured(), search(), cheapestNight()
// 2) أضفه إلى مصفوفة LIVE أدناه. الخادم يدمج عروض كل المزوّدين لكل فندق تلقائياً.
import { liteapiProvider } from './liteapi.js';
import { demoProvider } from './demo.js';

const LIVE = [liteapiProvider];

export const activeProviders = () => LIVE.filter((p) => p.isConfigured());
export { demoProvider };
