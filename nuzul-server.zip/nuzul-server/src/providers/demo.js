// مزوّد تجريبي: يولّد عقارات وأسعاراً ثابتة لكل مدينة (بلا إنترنت).
// يُستخدم للتطوير، وتلقائياً عند غياب مفتاح LiteAPI أو تعطله.
import { cityById } from '../cities.js';

const hash = (str) => { let h = 2166136261; for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; };
const rng = (seed) => { let a = seed >>> 0; return () => { a |= 0; a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; };
const pick = (r, arr) => arr[Math.floor(r() * arr.length)];

const H_PRE = ['فندق', 'فندق', 'منتجع', 'فندق وأجنحة'];
const H_NAMES = ['مدار', 'ريحانة', 'السنبلة', 'لؤلؤة المدينة', 'الواحة', 'نجمة الصباح', 'الديوان', 'القمرية', 'البوابة', 'الأفق', 'السدرة', 'المرجان', 'ياقوت', 'الروشن', 'قصر النخيل', 'الغيمة', 'الفنار', 'سَنا'];
const A_PRE = ['شقق', 'أجنحة', 'استوديوهات', 'نُزُل'];
const A_NAMES = ['النخبة', 'دار الضيافة', 'الريم', 'الزاوية', 'نسيم', 'السكينة', 'المرسى', 'رواق', 'لافندر', 'الياسمينة', 'المها', 'بيت الجود'];
const AMEN = ['wifi', 'breakfast', 'pool', 'parking', 'gym', 'kitchen', 'family'];
const PROVIDERS = ['رحّال', 'مسار', 'بوابة السفر'];

const DAY = 864e5;
const parse = (s) => { const [y, m, d] = s.split('-').map(Number); return new Date(Date.UTC(y, m - 1, d)); };
const iso = (d) => d.toISOString().slice(0, 10);

const cache = {};
function propsFor(cityId) {
  if (cache[cityId]) return cache[cityId];
  const c = cityById(cityId), r = rng(hash(cityId + 'v3')), out = [], used = new Set();
  for (let i = 0; i < 16; i++) {
    const type = r() < 0.58 ? 'hotel' : 'apt';
    let name;
    do { name = type === 'hotel' ? `${pick(r, H_PRE)} ${pick(r, H_NAMES)}` : `${pick(r, A_PRE)} ${pick(r, A_NAMES)}${r() < 0.4 ? ' المفروشة' : ''}`; } while (used.has(name));
    used.add(name);
    const stars = type === 'hotel' ? (r() < 0.3 ? 5 : r() < 0.6 ? 4 : 3) : null;
    const baseByStars = { 3: 210, 4: 360, 5: 690 };
    const base = (type === 'hotel' ? baseByStars[stars] : 170 + r() * 260) * c.f * (0.82 + r() * 0.42);
    const rating = Math.round((7 + r() * 2.7 + (stars === 5 ? 0.2 : 0)) * 10) / 10;
    const amen = AMEN.filter((k) => {
      if (k === 'kitchen') return type === 'apt' ? r() < 0.9 : false;
      if (k === 'breakfast') return type === 'hotel' ? r() < 0.7 : r() < 0.2;
      if (k === 'pool') return r() < (stars === 5 ? 0.9 : 0.35);
      if (k === 'gym') return r() < (type === 'hotel' ? 0.6 : 0.25);
      return r() < 0.75;
    });
    const mults = [1 + r() * 0.14, 1 + r() * 0.14, 1 + r() * 0.14];
    mults[Math.floor(r() * 3)] = 0.96 + r() * 0.05;
    out.push({ id: cityId + '-' + i, type, name, stars, rating: Math.min(rating, 9.8), reviews: Math.floor(60 + r() * 3200),
      district: pick(r, c.districts), dist: Math.round((0.3 + r() * 11) * 10) / 10, amen, freeCancel: r() < 0.6, base, mults, hue: Math.floor(r() * 360) });
  }
  return (cache[cityId] = out);
}

function nightPrice(p, city, date) {
  const dow = date.getUTCDay();
  const weekend = city.cc === 'SA' || city.cc === 'AE' ? dow === 4 || dow === 5 : dow === 5 || dow === 6;
  const noise = 0.9 + rng(hash(p.id + iso(date)))() * 0.2;
  return p.base * (weekend ? 1.2 : 1) * noise;
}

export const demoProvider = {
  id: 'demo',
  label: 'بيانات تجريبية',
  isConfigured: () => true,

  async search({ city, checkin, checkout, guests }) {
    const start = parse(checkin), end = parse(checkout);
    const nights = Math.round((end - start) / DAY);
    return propsFor(city.id).map((p) => {
      let raw = 0;
      for (let d = start; d < end; d = new Date(d.getTime() + DAY)) raw += nightPrice(p, city, d);
      raw *= guests > 2 ? 1 + (guests - 2) * 0.12 : 1;
      return {
        id: p.id, name: p.name, type: p.type, stars: p.stars, rating: p.rating, reviews: p.reviews,
        district: p.district, dist: p.dist, amen: p.amen, freeCancel: p.freeCancel, board: p.amen.includes('breakfast') ? 'الإفطار متاح' : null,
        image: null, hue: p.hue,
        offers: p.mults.map((m, i) => ({ provider: PROVIDERS[i], total: Math.round((raw * m) / 5) * 5, url: null })),
        nights,
      };
    });
  },

  async cheapestNight({ city, date, type }) {
    const d = parse(date);
    const props = propsFor(city.id).filter((p) => !type || type === 'all' || p.type === type);
    return Math.round(Math.min(...props.map((p) => nightPrice(p, city, d) * Math.min(...p.mults))) / 5) * 5;
  },
};
