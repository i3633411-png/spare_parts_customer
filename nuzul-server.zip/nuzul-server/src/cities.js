// الوجهات المدعومة. en/cc تُرسل للمزوّد، و lat/lng مركز المدينة لحساب المسافة.
export const CITIES = [
  { id: 'makkah',   name: 'مكة المكرمة',     en: 'Mecca',    cc: 'SA', country: 'السعودية', vat: true,  center: 'المسجد الحرام',  lat: 21.4225, lng: 39.8262, f: 1.3,  districts: ['العزيزية', 'أجياد', 'الششة', 'النسيم', 'الروضة'] },
  { id: 'jeddah',   name: 'جدة',             en: 'Jeddah',   cc: 'SA', country: 'السعودية', vat: true,  center: 'الكورنيش',       lat: 21.5433, lng: 39.1728, f: 0.95, districts: ['الكورنيش', 'الروضة', 'البلد التاريخية', 'الشاطئ', 'الحمراء', 'أبحر'] },
  { id: 'riyadh',   name: 'الرياض',          en: 'Riyadh',   cc: 'SA', country: 'السعودية', vat: true,  center: 'مركز المدينة',   lat: 24.7136, lng: 46.6753, f: 1.0,  districts: ['العليا', 'الملقا', 'حي السفارات', 'النخيل', 'الورود', 'الياسمين'] },
  { id: 'madinah',  name: 'المدينة المنورة', en: 'Medina',   cc: 'SA', country: 'السعودية', vat: true,  center: 'المسجد النبوي',  lat: 24.4672, lng: 39.6112, f: 1.0,  districts: ['المنطقة المركزية', 'قباء', 'العزيزية', 'الخالدية'] },
  { id: 'alula',    name: 'العُلا',           en: 'AlUla',    cc: 'SA', country: 'السعودية', vat: true,  center: 'البلدة القديمة', lat: 26.6167, lng: 37.9167, f: 1.55, districts: ['البلدة القديمة', 'وادي عشار', 'الجهة الجنوبية'] },
  { id: 'abha',     name: 'أبها',            en: 'Abha',     cc: 'SA', country: 'السعودية', vat: true,  center: 'وسط أبها',       lat: 18.2164, lng: 42.5053, f: 0.7,  districts: ['السودة', 'المنسك', 'الخالدية', 'المفتاحة'] },
  { id: 'dubai',    name: 'دبي',             en: 'Dubai',    cc: 'AE', country: 'الإمارات', vat: false, center: 'وسط المدينة',    lat: 25.1972, lng: 55.2744, f: 1.45, districts: ['مرسى دبي', 'وسط المدينة', 'ديرة', 'الخليج التجاري', 'جميرا'] },
  { id: 'istanbul', name: 'إسطنبول',         en: 'Istanbul', cc: 'TR', country: 'تركيا',    vat: false, center: 'ميدان تقسيم',    lat: 41.0369, lng: 28.9850, f: 0.8,  districts: ['تقسيم', 'السلطان أحمد', 'شيشلي', 'بشكتاش', 'الفاتح'] },
  { id: 'cairo',    name: 'القاهرة',         en: 'Cairo',    cc: 'EG', country: 'مصر',      vat: false, center: 'وسط البلد',      lat: 30.0444, lng: 31.2357, f: 0.6,  districts: ['الزمالك', 'جاردن سيتي', 'مصر الجديدة', 'الدقي', 'وسط البلد'] },
];

export const cityById = (id) => CITIES.find((c) => c.id === id);

// المسافة بالكيلومتر بين نقطتين (Haversine)
export function distanceKm(lat1, lng1, lat2, lng2) {
  if ([lat1, lng1, lat2, lng2].some((v) => typeof v !== 'number' || Number.isNaN(v))) return null;
  const R = 6371, toRad = (d) => (d * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1), dLng = toRad(lng2 - lng1);
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) ** 2;
  return Math.round(R * 2 * Math.asin(Math.sqrt(a)) * 10) / 10;
}
